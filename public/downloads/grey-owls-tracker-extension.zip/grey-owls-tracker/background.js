// Signs in to Grey Owls Tracker and logs the Remotasks task you paste in: Start logs it as In
// Progress with its timer running, and Submitted marks it so, which stops the timer. The times are
// kept by the database (task_submissions_timer in supabase/migrations/20261024_task_timers.sql),
// so this only sets the status and starts or pauses the timer. Nothing is read from Remotasks.

// The same public project URL and anon key the tracker's own pages use (src/lib/supabaseConfig.ts).
const SUPABASE_URL = 'https://ieovepkcseytccagzedg.supabase.co'
const SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imllb3ZlcGtjc2V5dGNjYWd6ZWRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkxNjU1NDUsImV4cCI6MjEwNDc0MTU0NX0.OMZEAONl3XoSwjb_RhYo70fYXThONXVBGQLlGF-OQ7s'

const SUBMISSION_FIELDS = 'id,task_id,user_id,project_id,stage,status,snipboard_url,created_at,timer_started_at,timer_elapsed_seconds'
// Refresh the sign-in this long before it runs out.
const REFRESH_MARGIN_S = 60
// A Remotasks task ID: 24 characters of 0-9 and a-f (as in src/lib/remotasks.ts).
const TASK_ID_PATTERN = /^[0-9a-f]{24}$/i

// --- storage ---------------------------------------------------------------------------------

async function load(key) {
  return (await chrome.storage.local.get(key))[key] ?? null
}

async function save(values) {
  await chrome.storage.local.set(values)
}

// --- Supabase --------------------------------------------------------------------------------

async function authRequest(grantType, body) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=${grantType}`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.error_description || data.msg || 'Could not sign in.')
  return { accessToken: data.access_token, refreshToken: data.refresh_token, expiresAt: data.expires_at, userId: data.user.id }
}

async function accessToken() {
  const session = await load('session')
  if (!session) throw new Error('Sign in to Grey Owls Tracker first.')
  if (session.expiresAt - REFRESH_MARGIN_S > Date.now() / 1000) return session.accessToken
  try {
    const refreshed = await authRequest('refresh_token', { refresh_token: session.refreshToken })
    await save({ session: refreshed })
    return refreshed.accessToken
  } catch {
    await signOut()
    throw new Error('Your sign-in ran out. Sign in again.')
  }
}

async function rest(path, { method = 'GET', body } = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${await accessToken()}`,
      'Content-Type': 'application/json',
      Prefer: 'return=representation',
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => null)
  if (!res.ok) {
    const error = new Error(data?.message || `The tracker said ${res.status}.`)
    error.code = data?.code
    throw error
  }
  return data
}

// --- account ---------------------------------------------------------------------------------

async function signIn(email, password) {
  const session = await authRequest('password', { email: email.trim(), password })
  await save({ session })
  await loadAccount(session.userId)
}

// Your profile and the projects to choose from, fresh from the tracker: the ones you're assigned
// among your lead's (all of your lead's until you're assigned any; every project without a lead),
// as on the tracker (src/lib/cbProjects.ts). The first is picked until you choose another.
async function loadAccount(userId) {
  const [profile] = await rest(`profiles?id=eq.${userId}&select=id,name,email,role,remotasks_id,lead_id`)
  if (!profile) throw new Error('No tracker profile found for this account.')
  let projects
  let assigned = []
  if (profile.lead_id) {
    const [leadRows, levels] = await Promise.all([
      rest(`project_leads?lead_id=eq.${profile.lead_id}&select=project_id,projects(id,name,code)`),
      rest(`contributor_project_levels?user_id=eq.${userId}&select=project_id`),
    ])
    const leadProjects = leadRows.map((row) => row.projects).filter(Boolean)
    const mine = new Set(levels.map((row) => row.project_id))
    assigned = leadProjects.filter((project) => mine.has(project.id))
    projects = assigned.length > 0 ? assigned : leadProjects
  }
  if (!projects || projects.length === 0) projects = await rest('projects?select=id,name,code&order=name')
  projects.sort((a, b) => a.name.localeCompare(b.name))
  const settings = (await load('settings')) ?? {}
  if (!projects.some((p) => p.id === settings.projectId)) settings.projectId = projects[0]?.id ?? null
  // Tagged with an Octet Mind project: Unclaim is offered from sign-in, before any task is looked up.
  const canUnclaim = assigned.some(selfFilesRequests)
  await save({ profile, projects: projects.map(({ id, name }) => ({ id, name })), canUnclaim, settings: { stage: 'attempt', ...settings } })
}

// Reload: everything fresh from the tracker. A task that's done (submitted, expired, or no longer
// in the tracker) is cleared from here, ready for the next; one still in progress stays, as the
// tracker has it now.
async function reload() {
  const session = await load('session')
  if (!session) throw new Error('Sign in to Grey Owls Tracker first.')
  await loadAccount(session.userId)
  const [current, profile] = await Promise.all([load('current'), load('profile')])
  if (current?.taskId) {
    const { row } = await findOwnRow(current.taskId, profile.id)
    if (row?.status === 'in_progress') {
      await save({ current: { ...current, row } })
    } else {
      await save({ current: null })
    }
  }
  await updateBadge()
}

async function signOut() {
  await chrome.storage.local.remove(['session', 'profile', 'projects', 'current', 'canUnclaim'])
  await updateBadge()
}

// --- tasks -----------------------------------------------------------------------------------

// The tracker dates tasks in Singapore time (toISODate in src/lib/week.ts).
function todaySG() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Singapore' }).format(new Date())
}

/** The task ID in what was pasted: the ID itself, or a task link with it as ?sceneId=. */
function parseTaskId(input) {
  const text = String(input ?? '').trim()
  if (TASK_ID_PATTERN.test(text)) return text.toLowerCase()
  try {
    const id = new URL(text).searchParams.get('sceneId')
    if (id && TASK_ID_PATTERN.test(id)) return id.toLowerCase()
  } catch {
    // Not a link either.
  }
  return null
}

// The task being timed. `created` says whether the extension logged it (rather than it being
// logged before), which Reset needs to know.
async function setCurrent(taskId, row, created = false) {
  await save({ current: { taskId, row, created } })
  await updateBadge()
}

async function findOwnRow(taskId, userId) {
  const [row] = await rest(`task_submissions?task_id=eq.${taskId}&select=${SUBMISSION_FIELDS}`)
  if (row && row.user_id !== userId) return { taken: true }
  return { row }
}

async function setTimer(id, running) {
  const [row] = await rest(`task_submissions?id=eq.${id}&select=${SUBMISSION_FIELDS}`, {
    method: 'PATCH',
    // Any value starts it: the database replaces it with its own time.
    body: { timer_started_at: running ? new Date().toISOString() : null },
  })
  return row
}

// Logs the task as In Progress with its timer running, or picks the timer back up on one already
// logged. Starting one pauses any other timer you have running (the database runs one at a time).
async function start(input) {
  const [profile, settings, current, projects] = await Promise.all([load('profile'), load('settings'), load('current'), load('projects')])
  // Your chosen project, else the first of yours (what the picker shows).
  const projectId = settings?.projectId ?? projects?.[0]?.id ?? null
  if (!profile) throw new Error('Sign in to Grey Owls Tracker first.')
  const taskId = parseTaskId(input)
  if (!taskId) throw new Error('That isn’t a task ID. A task ID is 24 characters of 0-9 and a-f.')
  if (!projectId) throw new Error('You have no project in the tracker yet. Ask your lead to add you to one.')

  const found = await findOwnRow(taskId, profile.id)
  if (found.taken) throw new Error('Someone else already logged this task ID.')
  let row = found.row
  // Starting the same task again keeps knowing the extension logged it.
  const created = !row || (current?.taskId === taskId && Boolean(current.created))
  if (row) {
    if (row.status !== 'in_progress') throw new Error('You already logged this task, and it isn’t in progress any more.')
    if (!row.timer_started_at) row = await setTimer(row.id, true)
  } else {
    try {
      ;[row] = await rest(`task_submissions?select=${SUBMISSION_FIELDS}`, {
        method: 'POST',
        body: {
          cb_email: profile.email,
          user_id: profile.id,
          task_id: taskId,
          project_id: projectId,
          stage: settings.stage,
          status: 'in_progress',
          date: todaySG(),
          timer_started_at: new Date().toISOString(),
        },
      })
    } catch (err) {
      if (err.code === '23505') throw new Error('Someone else already logged this task ID.')
      throw err
    }
  }
  await setCurrent(taskId, row, created)
}

async function pauseOrResume(running) {
  const current = await load('current')
  if (!current?.row) return
  const row = await setTimer(current.row.id, running)
  await save({ current: { ...current, row } })
  await updateBadge()
}

/** The screenshot link as the tracker stores it: an http(s) link, or null for none. */
function parseScreenshotUrl(input) {
  const text = String(input ?? '').trim()
  if (!text) return null
  try {
    const url = new URL(text)
    if (url.protocol === 'http:' || url.protocol === 'https:') return text
  } catch {
    // Not a link.
  }
  throw new Error('The screenshot link should start with https://.')
}

// Saves the screenshot link on the current task (the Screenshot link on the tracker's form).
async function setScreenshot(input) {
  const current = await load('current')
  if (!current?.row) return
  const [row] = await rest(`task_submissions?id=eq.${current.row.id}&select=${SUBMISSION_FIELDS}`, {
    method: 'PATCH',
    body: { snipboard_url: parseScreenshotUrl(input) },
  })
  if (!row) throw new Error('This task isn’t in the tracker any more.')
  await save({ current: { ...current, row } })
}

// Marks it Submitted, which stops its timer, with the screenshot link if one was given.
async function markSubmitted(screenshot) {
  const current = await load('current')
  if (!current?.row) return
  const body = { status: 'submitted', submitted_at: todaySG() }
  if (screenshot !== undefined) body.snipboard_url = parseScreenshotUrl(screenshot)
  const [row] = await rest(`task_submissions?id=eq.${current.row.id}&status=eq.in_progress&select=${SUBMISSION_FIELDS}`, {
    method: 'PATCH',
    body,
  })
  // Nothing comes back when it wasn't in progress any more (submitted or changed in the tracker).
  if (!row) throw new Error('This task isn’t in progress in the tracker any more.')
  await save({ current: { ...current, row } })
  await updateBadge()
}

// For a wrong task ID: clears the current task, so the right one can be started. With `remove`
// it's also taken out of the tracker (only while it's still in progress); without, it stays there
// with its timer paused. Goes by the task as the tracker has it now, not as it was last seen here.
async function reset(remove) {
  const [current, profile] = await Promise.all([load('current'), load('profile')])
  if (current?.taskId && profile) {
    const { row } = await findOwnRow(current.taskId, profile.id)
    if (row && remove) {
      if (row.status !== 'in_progress') {
        throw new Error('Only a task that’s still in progress can be removed here. Change it on your Submissions in the tracker.')
      }
      const removed = await rest(`task_submissions?id=eq.${row.id}&status=eq.in_progress`, { method: 'DELETE' })
      // The tracker answers with what it removed; nothing means it wasn't allowed to.
      if (!removed?.length) throw new Error('The tracker didn’t remove this task. Remove it on your Submissions in the tracker.')
    } else if (row?.timer_started_at) {
      await setTimer(row.id, false)
    }
  }
  await save({ current: null })
  await updateBadge()
}

// --- requests ------------------------------------------------------------------------------

// Extension and reclaim requests, as on the tracker's Submissions table: for your own task while
// it's in progress or expired, with a reason, and only during your lead's shift (the database
// checks the same: task_requests_within_lead_shift).
const REQUESTABLE_STATUSES = ['in_progress', 'expired']

function sgMinutesNow() {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Singapore', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date())
  const get = (type) => Number(parts.find((p) => p.type === type).value)
  return get('hour') * 60 + get('minute')
}

function inShift({ starts_min: starts, ends_min: ends }) {
  const now = sgMinutesNow()
  return starts < ends ? now >= starts && now < ends : now >= starts || now < ends
}

function timeLabel(minutes) {
  const h = Math.floor(minutes / 60)
  const m = String(minutes % 60).padStart(2, '0')
  return `${h % 12 || 12}:${m} ${h < 12 ? 'AM' : 'PM'}`
}

async function requestableRow(input) {
  const profile = await load('profile')
  if (!profile) throw new Error('Sign in to Grey Owls Tracker first.')
  const taskId = parseTaskId(input)
  if (!taskId) throw new Error('That isn’t a task ID. A task ID is 24 characters of 0-9 and a-f.')
  const found = await findOwnRow(taskId, profile.id)
  if (found.taken) throw new Error('This task was logged by someone else.')
  if (!found.row) throw new Error('This task isn’t in the tracker yet. Start it first.')
  return { profile, row: found.row }
}

/** Your requests on a task, newest first, or why there can't be any. */
async function taskRequests(input) {
  const taskId = parseTaskId(input)
  const profile = await load('profile')
  if (!profile) return { requests: [] }
  if (!taskId) return { requests: [], note: 'That isn’t a task ID. A task ID is 24 characters of 0-9 and a-f.' }
  const found = await findOwnRow(taskId, profile.id)
  if (found.taken) return { requests: [], note: 'This task was logged by someone else.' }
  if (!found.row) return { requests: [], note: 'This task isn’t in the tracker yet. Start it on the Timer tab first.' }
  const [requests, project] = await Promise.all([
    rest(`task_requests?task_submission_id=eq.${found.row.id}&type=in.(extension,reclaim,unclaim)&select=id,type,status,reason,requested_at&order=requested_at.desc`),
    projectOf(found.row),
  ])
  return { requests, selfFiles: selfFilesRequests(project) }
}

async function projectOf(row) {
  if (!row.project_id) return null
  const [project] = await rest(`projects?id=eq.${row.project_id}&select=name,code`)
  return project ?? null
}

// Octet Mind's extensions, reclaims and unclaims are filed by the contributor on its TASK ISSUES form, not
// sent to the lead: the same rule as timeRequestFormFor() in the tracker (src/lib/taskRequests.ts).
const TASK_ISSUES_FORM_URL = 'https://docs.google.com/forms/d/e/1FAIpQLSdSToZndSe2yOh2bp2aGT07RByEwWsG-K_7Dih3J6oias5XRA/viewform'

function selfFilesRequests(project) {
  const code = String(project?.code ?? '').trim().toLowerCase().replace(/[\s_-]+/g, '')
  if (code) return code === 'octetmind'
  return /octet/i.test(project?.name ?? '')
}

function taskIssuesFormUrl({ type, taskId, email, remotasksId, reason }) {
  const query = new URLSearchParams({ usp: 'pp_url' })
  if (taskId) query.set('entry.386497914', taskId)
  if (remotasksId) query.set('entry.673063933', remotasksId)
  if (email) query.set('entry.899316383', email)
  if (type === 'unclaim') {
    query.set('entry.1173139433', '__other_option__')
    query.set('entry.1173139433.other_option_response', 'Unclaim')
  } else {
    query.set('entry.1173139433', type === 'reclaim' ? 'Reclaim' : 'Extend')
  }
  if (reason) query.set('entry.1706519998', reason)
  query.set('entry.949669351', 'REMOTE - BOOTCAMP')
  return `${TASK_ISSUES_FORM_URL}?${query}`
}

async function sendRequest(input, type, reason) {
  if (!['extension', 'reclaim', 'unclaim'].includes(type)) throw new Error('Choose Extension, Reclaim or Unclaim.')
  if (!String(reason ?? '').trim()) throw new Error('Give a reason.')
  const { profile, row } = await requestableRow(input)
  if (!REQUESTABLE_STATUSES.includes(row.status)) throw new Error('Requests are only for tasks that are in progress or expired.')

  const selfFiles = selfFilesRequests(await projectOf(row))
  if (type === 'unclaim' && !selfFiles) throw new Error('Unclaim is only for Octet Mind tasks.')
  if (selfFiles) {
    // Recorded first (file_own_task_request in 20261110_self_filed_task_issues.sql), then the form
    // opens in a new tab, which closes this popup.
    await rest('rpc/file_own_task_request', { method: 'POST', body: { p_submission_id: row.id, p_type: type, p_reason: reason.trim() } })
    await chrome.tabs.create({
      url: taskIssuesFormUrl({ type, taskId: row.task_id, email: profile.email, remotasksId: profile.remotasks_id, reason: reason.trim() }),
    })
    return { selfFiled: true }
  }

  const [shift] = await rest('rpc/request_shift', { method: 'POST', body: {} })
  if (shift && !inShift(shift)) {
    throw new Error(`Extension and reclaim requests open during ${shift.lead_name}'s shift, ${timeLabel(shift.starts_min)} – ${timeLabel(shift.ends_min)}.`)
  }
  await rest('task_requests', {
    method: 'POST',
    body: {
      type,
      task_submission_id: row.id,
      requested_by: profile.id,
      reason: reason.trim(),
      remotasks_id: profile.remotasks_id ?? null,
    },
  })
  return { selfFiled: false }
}

async function updateBadge() {
  const current = await load('current')
  await chrome.action.setBadgeText({ text: current?.row?.timer_started_at ? 'REC' : '' })
  await chrome.action.setBadgeBackgroundColor({ color: '#16a34a' })
}

// --- messages --------------------------------------------------------------------------------

// One at a time, so a double click can't log a task twice.
let queue = Promise.resolve()
function serially(work) {
  const next = queue.then(work, work)
  queue = next.catch(() => {})
  return next
}

async function handle(message) {
  switch (message.type) {
    case 'sign-in':
      return signIn(message.email, message.password)
    case 'sign-out':
      return signOut()
    case 'set-settings': {
      const settings = { ...((await load('settings')) ?? {}), ...message.settings }
      await save({ settings })
      return
    }
    case 'start':
      return start(message.taskId)
    case 'pause':
      return pauseOrResume(false)
    case 'resume':
      return pauseOrResume(true)
    case 'mark-submitted':
      return markSubmitted(message.screenshot)
    case 'set-screenshot':
      return setScreenshot(message.screenshot)
    case 'reload':
      return reload()
    case 'reset':
      return reset(Boolean(message.remove))
    case 'get-requests':
      return taskRequests(message.taskId)
    case 'send-request':
      return sendRequest(message.taskId, message.requestType, message.reason)
    case 'get-state': {
      let data = await chrome.storage.local.get(['session', 'profile', 'projects', 'settings', 'current', 'canUnclaim'])
      // Signed in before canUnclaim was stored: fetch the account once so Unclaim shows without a reload.
      if (data.session && data.canUnclaim === undefined) {
        try {
          await loadAccount(data.session.userId)
          data = await chrome.storage.local.get(['session', 'profile', 'projects', 'settings', 'current', 'canUnclaim'])
        } catch (err) {
          console.warn('Grey Owls Tracker: account refresh failed', err)
        }
      }
      return { ...data, session: Boolean(data.session) }
    }
  }
}

chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  serially(() => handle(message))
    .then((result) => reply({ ok: true, result }))
    .catch((err) => {
      // Also in the extension's console (brave://extensions → Inspect views: service worker).
      console.error(`Grey Owls Tracker: ${message.type} failed`, err)
      reply({ ok: false, error: err instanceof Error ? err.message : String(err) })
    })
  return true
})
